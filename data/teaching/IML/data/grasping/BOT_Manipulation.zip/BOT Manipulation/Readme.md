In this practical session, we will compute and evaluate grasps on a given object. We will use the gripper configuration of the Franka Emika Panda robot.

You will be given an object model (a mesh), on which you will have to sample and evaluate grasp candidates, in order to select the best grasp found. Since the Panda robot has a linear gripper with only two fingers, a grasp can be represented as a segment in 3D space connecting two contact points on the surface of the object.

Let us implement this below.

First, let us install the dependencies

\# 0. Install Jupyter Notebook

pip3 install --user notebook

\# 1. Install the PyBullet simulator or the OpenAI gym

pip3 install --user gym

pip3 install --user pybullet

\# 2. Install TriMesh

pip3 install --user trimesh

Download the files from cloud.imt-atlantique.fr and run the Jupyter Notebook:

jupyter notebook TP.ipynb